<?php

namespace App\Services;

use App\Models\Article;
use App\Models\Collections\ArticlesCollection;
use jcobhams\NewsApi\NewsApi;

class IndexArticleService
{
    private NewsApi $api;

    public function __construct()
    {
        $this->api = new NewsApi($_ENV['NEWS_API_KEY']);
    }

    public function execute(string $search, ?string $category = null): ArticlesCollection
    {
        $articlesApiResponse = $this->getArticles($search, $category);

        $articles = new ArticlesCollection();
        foreach ($articlesApiResponse->articles as $article) {
            $articles->add(new Article(
                $article->title,
                $article->url,
                $article->description,
                $article->publishedAt,
                $article->urlToImage
            ));
        }
        return $articles;
    }


    private function getArticles(string $search, ?string $category = null)
    {
        if (!$category) {
            return $this->api->getEverything($search, null, null, null, null, null, null, null, 10);
        }

        return $this->api->getTopHeadLines($category, null, null, null, 10);
    }
}