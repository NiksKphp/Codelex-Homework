# 30.11.2022 Mājasdarbs

API key must be entered in .env file 

![Screenshot](https://github.com/NiksKphp/Screenshots/blob/main/30_11.png)
