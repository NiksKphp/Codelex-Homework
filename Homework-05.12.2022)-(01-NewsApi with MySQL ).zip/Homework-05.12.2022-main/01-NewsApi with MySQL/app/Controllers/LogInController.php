<?php

namespace App\Controllers;

use App\Redirect;
use App\Template;
use App\Services\DatabaseService;

class LogInController
{
    public function showForm(): Template
    {
        return new Template('login.twig');
    }

    public function validate():Redirect
    {
        $email = $_POST['email'];
        $password = $_POST['password'];

        $databaseService = new DatabaseService();
        $getUserID = $databaseService->validateLogIn($email, $password);
        $_SESSION['id']=$getUserID;

        if (is_numeric($getUserID)) {
            $userName = $databaseService->getUserName($getUserID);
            $_SESSION['name'] = $userName;
            return new Redirect('/articles');
        } else {
            return new Redirect('/'); // todo error fail
        }
    }
}