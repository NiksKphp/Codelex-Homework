<?php

namespace App\Controllers;

use App\Redirect;
use App\Services\EditProfileDataService;
use App\Template;

class ProfileController
{
    public function showForm(): Template
    {

        return new Template(
            'profile.twig',
            [
                'userInfo' => ['name'=>"{$_SESSION['name']}"],
                'msg' => ['msg'=>"{$_SESSION['msg']}"]
            ]
        );
    }

    public function save() : Redirect
    {
        if (!($_POST['name'] == null)) {
            (new EditProfileDataService())->editName($_POST['name'],$_SESSION['id']);
        } else {
            $_SESSION['errors']['password'] = 'froSAVE';
        }

        if (!($_POST['email'] == null)) {
            (new EditProfileDataService())->editEmail($_POST['email'],$_SESSION['id']);
        }

        if (!($_POST['password'] == null)||!($_POST['passwordRepeat'] == null)) {
            if ($_POST['password'] == $_POST['passwordRepeat']) {
                (new EditProfileDataService())->editPassword($_POST['password'], $_SESSION['id']);
            }
        }

        $_SESSION['msg'] = "Confirmed";

        return new Redirect('/profile');
    }
}