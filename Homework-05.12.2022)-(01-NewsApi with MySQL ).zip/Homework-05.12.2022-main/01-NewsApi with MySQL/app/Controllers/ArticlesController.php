<?php

namespace App\Controllers;

use App\Redirect;
use App\Services\IndexArticleService;
use App\Template;

class ArticlesController
{
    public function index():Template
    {
        $search = $_GET['search'] ?? 'breaking news';
        $category = $_GET['category'];

        $articles = (new IndexArticleService())->execute($search,$category);

        return new Template(
            'articles/index.twig',
            [
                'articles' => $articles->get(),
                'userInfo' => ['name'=>"{$_SESSION['name']}"]
            ]
        );
    }

    public function logOut():Redirect
    {
        session_destroy(); // delete only specific data in future like username, not destroy all.
        return new Redirect('/');
    }

}