<?php

namespace App\Controllers;

use App\Redirect;
use App\Services\DatabaseService;
use App\Services\RegisterServiceRequest;
use App\Template;

class RegisterController
{
    public function showForm(): Template
    {
        return new Template('register.twig');
    }

    public function store():Redirect
    {
        $databaseService = new DatabaseService();

        if (($_POST['passwordRepeat'] !== $_POST['password'])
            || ($_POST['password'] == null)
            || ($_POST['email'] == null)) {
            return new Redirect('/register');
        } else {
            $databaseService->execute(
                new RegisterServiceRequest(
                    $_POST['name'],
                    $_POST['email'],
                    $_POST['password'],
                )
            );
        }
        return new Redirect('/');
    }
}