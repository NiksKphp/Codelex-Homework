<?php

namespace App\Services;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\DriverManager;

class DatabaseService
{
    private static ?Connection $connection = null;

    public function __construct()
    {
        self::getConnection();
    }

    public static function getConnection(): ?Connection
    {
        if (self::$connection == null) {
            $connectionParams = [
                'dbname' => $_ENV['DATABASE_NAME'],
                'user' => $_ENV['USER'],
                'password' => $_ENV['PASSWORD'],
                'host' => $_ENV['HOST'],
                'driver' => 'pdo_mysql',
            ];
            self::$connection = DriverManager::getConnection($connectionParams);
        }

        return self::$connection;
    }

    public function execute(RegisterServiceRequest $request)
    {
        $query = "INSERT INTO users (name, email, password) VALUES ('{$request->getName()}', '{$request->getEmail()}', '{$request->getPassword()}')";

        self::$connection->executeQuery($query);
    }

    public function validateLogIn(string $email, string $password) // returns bool or number, what to do?? (: mixed ?)
    {
        $query = "select * from users where email ='{$email}'and password='{$password}'";

        return self::$connection->fetchOne($query);
    }

    public function getUserName(int $id) // returns bool or number, what to do?? (: mixed ?)
    {
        $query = "SELECT name FROM users WHERE id = {$id}";

        return self::$connection->fetchOne($query);
    }
}