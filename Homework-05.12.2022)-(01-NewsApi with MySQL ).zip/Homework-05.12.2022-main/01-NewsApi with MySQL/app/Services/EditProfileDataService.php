<?php

namespace App\Services;

use Doctrine\DBAL\Connection;

class EditProfileDataService
{
    private Connection $connection;

    public function __construct()
    {
        $connectionParams = [
            'dbname' => $_ENV['DATABASE_NAME'],
            'user' => $_ENV['USER'],
            'password' => $_ENV['PASSWORD'],
            'host' => $_ENV['HOST'],
            'driver' => 'pdo_mysql',
        ];

        $this->connection = \Doctrine\DBAL\DriverManager::getConnection($connectionParams);
    }

    public function editName(string $newName, int $id): void
    {
        $this->connection->update('users', ['name' => $newName], ['id' => $id]);
    }

    public function editEmail(string $newEmail, int $id): void
    {
        $this->connection->update('users', ['email' => $newEmail], ['id' => $id]);
    }

    public function editPassword(string $newPassword, int $id): void
    {
        $this->connection->update('users', ['password' => $newPassword], ['id' => $id]);
    }
}