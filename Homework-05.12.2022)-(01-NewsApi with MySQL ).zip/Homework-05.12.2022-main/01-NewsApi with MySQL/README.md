# 05.12.2022 && 07.12.2022 Mājasdarbs

API key and database connection data must be entered in .env file

## Login
![Screenshot](https://github.com/NiksKphp/Screenshots/blob/main/05_12_1.png)
## Register
![Screenshot](https://github.com/NiksKphp/Screenshots/blob/main/05_12_4.png)
# Logged in
![Screenshot](https://github.com/NiksKphp/Screenshots/blob/main/07_12_1.png)
# Edit profile
![Screenshot](https://github.com/NiksKphp/Screenshots/blob/main/07_12_2.png)
