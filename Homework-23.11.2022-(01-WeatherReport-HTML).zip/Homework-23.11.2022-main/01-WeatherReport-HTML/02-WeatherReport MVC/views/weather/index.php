<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body class="body">

<div class="container">
    <h2>Weather Report</h2>
</div>

<div class="topbar">
    <a href="home">Homepage</a>
</div>

<div class="topbar">
    <a href="weather?city=Riga">Riga</a>
    <a href="weather?city=Tallinn">Tallinn</a>
    <a href="weather?city=Vilnius">Vilnius</a>
</div>

<div class="inputContainer">
    <form name="form" action="" method="get">
        City: <input type="text" name="city" id="city" value="">
        <input type="submit">
    </form>
    <a class="warningText">Works only on big cities (due to nesbot/Carbon limitation) like Moscow, Rome, Paris, Tokyo...</a>
</div>

<?php
use Carbon\Carbon;


$weather = new App\Weather("$_GET[city]");

Carbon::macro('goTo', function (string $city) {
    static $cities = null;

    if ($cities === null) {
        foreach (DateTimeZone::listIdentifiers() as $identifier) {
            $chunks = explode('/', $identifier);

            if (isset($chunks[1])) {
                $id = strtolower(end($chunks));
                $cities[$id] = $identifier;
            }
        }
    }

    $city = str_replace(' ', '_', strtolower($city));

    if (!isset($cities[$city])) {
        throw new InvalidArgumentException("$city not found.");
    }

    return $this->tz($cities[$city]);
});

$locationForCarbon = Carbon::now()->goTo($_GET[city])->tzName;
$localtime = Carbon::now($locationForCarbon);
?>

<img src="<?php echo "http://openweathermap.org/img/wn/{$weather->getIcon()}@2x.png" ?>" style="width:100px;height:100px;  display: block; margin-left: auto; margin-right: auto;">

<?php
echo "<h2 style='text-align: center'>Local time: {$localtime}</h2>";
echo "<h2 style='text-align: center'>Temperature in $_GET[city] is {$weather->getTemperature()}°C</h2>";
echo "<h2 style='text-align: center'>Clouds are {$weather->getClouds()} and the wind speed is {$weather->getWind()} m/s</h2>";
?>

</body>
</html>