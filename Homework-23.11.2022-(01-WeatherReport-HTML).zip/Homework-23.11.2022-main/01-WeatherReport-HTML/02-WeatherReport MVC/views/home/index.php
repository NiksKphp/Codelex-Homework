<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body class="body">

<div class="container">
    <h2>Home Page</h2>
</div>

<div class="topbar">
    <a href="weather">Go to weather report</a>
</div>


</body>
</html>