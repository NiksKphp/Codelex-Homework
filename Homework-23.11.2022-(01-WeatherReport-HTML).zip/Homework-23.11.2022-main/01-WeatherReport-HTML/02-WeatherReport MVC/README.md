# 25.11.2022 Mājasdarbs


API key must be entered in  ApiHandler Class app/ApiHandler.php file ApiHandler Class
