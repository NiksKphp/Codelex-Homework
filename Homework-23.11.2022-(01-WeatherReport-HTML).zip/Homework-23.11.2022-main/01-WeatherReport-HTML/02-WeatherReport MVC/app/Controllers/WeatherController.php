<?php

namespace App\Controllers;

use App\Models\Weather;

class WeatherController
{
    public function index()
    {
        //$weather = new Weather();

        //require_once 'views/weather/index.php';

        return "weather/index.php";

    }
}