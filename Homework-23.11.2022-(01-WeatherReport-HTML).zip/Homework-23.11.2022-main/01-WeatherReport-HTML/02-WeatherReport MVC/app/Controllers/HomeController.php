<?php

namespace App\Controllers;

use App\Models\Home;

class HomeController
{
    public function index()
    {
        //$weather = new Weather();

        //require_once 'views/home/index.php';

        return "home/index.php";

    }
}