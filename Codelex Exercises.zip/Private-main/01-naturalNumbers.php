<?php

echo "The first 10 natural numbers are: ";

for ($i=1;$i<=10;$i++){
    echo "$i ";
}