<?php

$input = readline("Input number of terms: ");

for ($i=1;$i<=$input;$i++){
    $result = $i*$i;
}

echo $result;
